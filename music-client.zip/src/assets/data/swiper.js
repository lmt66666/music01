//轮播图的数据
const swiperList = [
    {picImg: require('@/assets/img/swiper/1.jpg')},
    {picImg: require('@/assets/img/swiper/2.jpg')},
    {picImg: require('@/assets/img/swiper/3.jpg')},
    {picImg: require('@/assets/img/swiper/4.jpg')},
    {picImg: require('@/assets/img/swiper/5.jpg')},
    {picImg: require('@/assets/img/swiper/6.jpg')},
    {picImg: require('@/assets/img/swiper/7.jpg')},
    {picImg: require('@/assets/img/swiper/8.jpg')}    
]

export {
    swiperList
}